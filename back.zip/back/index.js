const mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const db = mysql.createPool({
    host:'localhost',
    user:'tutorias_user',
    password:'1234',
    database: 'tutorias'
});

const app = express();
const port = 5000;

app.use(bodyParser.json());
app.use(cors());

app.get('/',(req,res) =>{
    res.send('Hola mundo');
});
app.post('/alumno/agrgar', (req,res)=>{
    const { matricula, aPaterno, aMaterno,nombre, sexo,dCalle,dNumero,dColonia,dCodigoPostal,aTelefono,aCorreo,aFacebook,aInstagram} = req.body;
    const sql = "INSERT INTO alumnos values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    db.query(sql, [matricula, aPaterno, aMaterno,nombre, sexo,dCalle,dNumero,dColonia,dCodigoPostal,aTelefono,aCorreo,aFacebook,aInstagram,"default.jpg"],(err,res)=>{
        if(err){
            res.send({
                status:100,
                errNo: err.errno,
                mensaje: err.sqlMessage,
                codigo:err.code,
            });
        }else{
            res.send({
                status:200,
            });
        }
    });
});
app.listen(port, ()=>{
    console.log(`escuchando en el puerto ${port}`);
});
