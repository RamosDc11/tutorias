function AlumnoEliminar() {
	return ( 
		<>
			<h1>Alumno eliminar</h1>
		</>
	 );
}

export default AlumnoEliminar;